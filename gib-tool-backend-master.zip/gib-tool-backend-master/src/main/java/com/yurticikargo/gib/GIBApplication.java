package com.yurticikargo.gib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GIBApplication {

	public static void main(String[] args) {
		SpringApplication.run(GIBApplication.class, args);
	}

}
