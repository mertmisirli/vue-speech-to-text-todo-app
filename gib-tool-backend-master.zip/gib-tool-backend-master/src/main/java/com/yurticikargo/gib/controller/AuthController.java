package com.yurticikargo.gib.controller;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.UserRecord;
import com.yurticikargo.gib.dto.request.LoginRequestDto;
import com.yurticikargo.gib.dto.request.RegisterRequestDto;
import com.yurticikargo.gib.dto.request.UpdateUserRequestDto;
import com.yurticikargo.gib.service.FirebaseAuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.yurticikargo.gib.constant.Constant.*;

@RestController
@RequestMapping(AUTH)
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class AuthController {

    private final FirebaseAuthService authService;


    @PostMapping(REGISTER)
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    public ResponseEntity<UserRecord> registerUser(@RequestBody RegisterRequestDto dto) throws FirebaseAuthException {
        return ResponseEntity.ok(authService.registerUser(dto));
    }

    @PostMapping(LOGIN)
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    public ResponseEntity<UserRecord> loginUser(@RequestBody LoginRequestDto dto) throws FirebaseAuthException {
        return ResponseEntity.ok(authService.loginUser(dto.getUsername(), dto.getPassword()));
    }

    @PutMapping(UPDATE)
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    public ResponseEntity<UserRecord> updateUser(@RequestBody UpdateUserRequestDto dto) throws FirebaseAuthException {
        return ResponseEntity.ok(authService.updateUserInfo(dto));
    }

}