package com.yurticikargo.gib.controller;
import com.yurticikargo.gib.dto.request.GIBRequestDto;
import com.yurticikargo.gib.dto.response.ExcelResponseDto;
import com.yurticikargo.gib.service.GIBPostRequestService;
import com.yurticikargo.gib.service.excelManager.ExcelService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.apache.poi.ss.usermodel.Workbook;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static com.yurticikargo.gib.constant.Constant.*;
@RestController
@RequestMapping(EXCEL)
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor

public class ExcelController {
    private final ExcelService excelService;
    private final GIBPostRequestService gibPostRequestService;

    @PostMapping(value = GETFILE, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    public ResponseEntity<byte[]> getListTrial(@RequestBody GIBRequestDto dto) {
        try {
            Workbook workbook = excelService.getEmbeddedExcelFile();

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            byte[] excelBytes = outputStream.toByteArray();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentDisposition(ContentDisposition.attachment().filename("your_excel_file.xlsx").build());
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            return new ResponseEntity<>(excelBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    //TODO: turnoff first trial method when this original one is ready to test
    /*@PostMapping(value = GETFILE, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    @CrossOrigin(origins = "*", allowedHeaders = "*")*/
    public ResponseEntity<byte[]> getList(@RequestBody GIBRequestDto dto) {
        try {
            ExcelResponseDto responseDto = excelService.getExcelList(dto);
            Workbook workbook = responseDto.getWorkbook();
            String fileName = responseDto.getFileName();

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            byte[] excelBytes = outputStream.toByteArray();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            return new ResponseEntity<>(excelBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }


}