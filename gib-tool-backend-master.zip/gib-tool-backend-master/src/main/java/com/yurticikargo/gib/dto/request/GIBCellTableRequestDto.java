package com.yurticikargo.gib.dto.request;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class GIBCellTableRequestDto {
    String date;
}