package com.yurticikargo.gib.dto.response;

import lombok.*;
import org.apache.poi.ss.usermodel.Workbook;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class ExcelResponseDto {

    Workbook workbook;
    String fileName;
}
