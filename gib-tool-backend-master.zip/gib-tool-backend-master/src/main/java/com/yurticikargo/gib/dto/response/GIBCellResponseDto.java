package com.yurticikargo.gib.dto.response;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class GIBCellResponseDto {

    private  Long id;
    private String posBankVkn;
    private String posMemberCompany;
    private String posBankName;
    private double sum;
}
