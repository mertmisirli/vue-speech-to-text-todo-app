package com.yurticikargo.gib.dto.response;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class GIBPostResponseDto {

    private String sqlMessage;
    private int rowCount;
}
