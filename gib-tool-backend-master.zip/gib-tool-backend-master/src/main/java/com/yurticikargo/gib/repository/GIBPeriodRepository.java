package com.yurticikargo.gib.repository;

import com.yurticikargo.gib.repository.entity.GIBPeriod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GIBPeriodRepository extends JpaRepository<GIBPeriod,Long> {
    Optional<GIBPeriod> findOptionalByYearMonth(String yearMonth);
}
