package com.yurticikargo.gib.repository.entity;

import com.yurticikargo.gib.repository.enums.State;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Builder
@Table(name = "GIB_PERIOD")
public class GIBPeriod {

    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Long id;
    @Column(name = "YEAR_MONTH")
    private String yearMonth;


    //sub info
    @Column(name = "CREATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    @Column(name = "STATE")
    @Enumerated(EnumType.ORDINAL)
    private State state;

    @PrePersist
    public void prePersist() {
        setCreateTime(new Date());
        setState(State.ACTIVE);
    }

}
