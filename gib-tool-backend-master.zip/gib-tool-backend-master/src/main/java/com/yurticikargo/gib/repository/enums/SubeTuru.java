package com.yurticikargo.gib.repository.enums;


import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum SubeTuru {

	Merkez(1,"Merkez"), MukellefiyetliSube(2,"Mukellefiyetli Sube"),MukellefiyetsizSube(3,"Mukellefiyetsiz Sube");

	private Integer code;

	private String name;

	
	public Integer getCode() {
		return code;
	}



	private SubeTuru(Integer code,String name) {
		this.code = code;
		this.name = name;
	}
	
	


	public String getName() {
		return name;
	}



	public void setCode(Integer code) {
		this.code = code;
	}




	private static final Map<Integer, SubeTuru> lookup = new HashMap<Integer, SubeTuru>();

	public static SubeTuru get(Integer activeFlag) {
		return lookup.get(activeFlag);
	}

	static {
		for (SubeTuru s : EnumSet.allOf(SubeTuru.class))
			lookup.put(s.getCode(), s);
	}
	
	
}
