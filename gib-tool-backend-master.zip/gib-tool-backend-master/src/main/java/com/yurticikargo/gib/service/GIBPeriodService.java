package com.yurticikargo.gib.service;

import com.yurticikargo.gib.exception.ErrorType;
import com.yurticikargo.gib.exception.GIBExceptionManager;
import com.yurticikargo.gib.repository.GIBPeriodRepository;
import com.yurticikargo.gib.repository.entity.GIBPeriod;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class GIBPeriodService {
    private final GIBPeriodRepository gibPeriodRepository;

    public GIBPeriod createPeriod(String year, String month){
        Optional<GIBPeriod> gibPeriod = gibPeriodRepository.findOptionalByYearMonth(year+month);
        if(gibPeriod.isEmpty()){
            return gibPeriodRepository.save(GIBPeriod.builder().yearMonth(year+month).build());
        }else return gibPeriod.get();
    }

    public Optional<GIBPeriod> findByDate(String year, String month){
        return gibPeriodRepository.findOptionalByYearMonth(year+month);
    }


    public GIBPeriod findById(Long id) {
        return gibPeriodRepository.findById(id).orElseThrow(()-> new GIBExceptionManager(ErrorType.PERIOD_IS_NOT_EXIST));
    }
    //TODO: burada database deki mevcut döneme ait verileri temizlemeliyiz
    public boolean deleteByPeriod(GIBPeriod gibPeriod) {
        return true;
    }
}
