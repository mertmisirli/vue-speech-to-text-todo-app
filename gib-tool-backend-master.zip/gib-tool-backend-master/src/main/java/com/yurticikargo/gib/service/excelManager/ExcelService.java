package com.yurticikargo.gib.service.excelManager;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import com.yurticikargo.gib.dto.request.GIBRequestDto;
import com.yurticikargo.gib.dto.response.ExcelResponseDto;
import com.yurticikargo.gib.exception.ErrorType;
import com.yurticikargo.gib.exception.GIBExceptionManager;
import com.yurticikargo.gib.utility.postislemleri.dto.Data;
import com.yurticikargo.gib.utility.postislemleri.dto.PosBilgileriTable;
import com.yurticikargo.gib.utility.postislemleri.dto.PosIslemleriResponse;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;


@Service
@RequiredArgsConstructor
public class ExcelService {

    public Workbook getEmbeddedExcelFile() {
        try {

            InputStream inputStream = getClass().getResource("/your_excel_file.xlsx").openStream();
            if(inputStream==null){
                throw new GIBExceptionManager(ErrorType.FILE_NULL);
            }

            Workbook workbook = WorkbookFactory.create(inputStream);

            return workbook;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    // MAIN//
    public ExcelResponseDto getExcelList(GIBRequestDto dto) throws Throwable  {
        // Set variables from DTO
        String token = dto.getToken();
        String year = dto.getDate().substring(0, 4);
        String month = dto.getDate().substring(5);
        Workbook finalWorkbook = null;
        String fileName = null;

        Unirest.setTimeouts(0, 0);

        /*token = "901610b6e39ca9d6d239ba2cc41fd6e3e0160d666878a08fa4402ce3e8fab2b5069bdc96f1475f6d3b8dc27f466e3790e34ae710319fbbdf8d8e45a70e4a4f67";*/
        /*year = "2023";*/
        /*month = "01";*/
        int pageNum   = 1;
        int totalRowCount = 0;
        PosIslemleriResponse readValue = fetchPageData(String.valueOf(pageNum), token, year, month);

        Integer rowCount 	           =  Integer.parseInt(readValue.getData().getPosListeSize());

        ExcelGenerator excelGenerator = new ExcelGenerator() ;

        excelGenerator.writeHeader();
        List<PosBilgileriTable> finalList = new ArrayList<>();

        while (totalRowCount < rowCount) {

            readValue = fetchPageData(String.valueOf(pageNum++), token, year, month);

            Data data = readValue.getData();

            List<PosBilgileriTable> posBilgileriTable = data.getPosBilgileriTable();


            finalList.addAll(posBilgileriTable);

            totalRowCount = totalRowCount+ posBilgileriTable.size();

        }

        System.out.println("xls'e aktarım bailadı."+ finalList.size());

        excelGenerator.writeLines(finalList);

        System.out.println("dosyaya yazma başladı."+ finalList.size());

        fileName = "gis_pos_islemleri"+"_"+year+"_"+month+".xlsx";
        // excelGenerator.generateExcelFile(fileName);
        finalWorkbook =  excelGenerator.generateExcelFile();

        return ExcelResponseDto.builder().workbook(finalWorkbook).fileName(fileName).build();
    }

    private static PosIslemleriResponse fetchPageData(String pageNumber, String token, String year, String month)
            throws UnsupportedEncodingException, UnirestException, JsonProcessingException, JsonMappingException {
        String jp ="{\"sayfa\":%s,\"ay1\":\"%s\",\"yil1\":\"%s\"}";
        String jpParam = URLEncoder.encode(String.format(jp, pageNumber,month,year), "UTF-8");

        HttpResponse<String> response =
                Unirest.get("https://intvrg.gib.gov.tr/intvrg_server/dispatch?cmd=posBilgileriIslemleri_posSonuc&callid=b9c09e173bfaa-13&token="+token+"&jp="+jpParam)
                        .asString();

        ObjectMapper objectMapper = new ObjectMapper();
        String body = response.getBody();

        System.out.println(body);

        PosIslemleriResponse readValue = objectMapper.readValue(body, PosIslemleriResponse.class);
        return readValue;
    }

}