
package com.yurticikargo.gib.utility.postislemleri.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import jakarta.annotation.Generated;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "data",
    "metadata"
})
@Generated("jsonschema2pojo")
public class PosIslemleriResponse {

    @JsonProperty("data")
    private Data data;
    @JsonProperty("metadata")
    private Metadata metadata;

    @JsonProperty("data")
    public Data getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(Data data) {
        this.data = data;
    }

    public PosIslemleriResponse withData(Data data) {
        this.data = data;
        return this;
    }

    @JsonProperty("metadata")
    public Metadata getMetadata() {
        return metadata;
    }

    @JsonProperty("metadata")
    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public PosIslemleriResponse withMetadata(Metadata metadata) {
        this.metadata = metadata;
        return this;
    }

}
